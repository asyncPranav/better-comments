"use strict";(()=>{var a="com.asyncpranav.bettercomments",u=[{test:t=>/\/\/\s*!|#\s*!/.test(t),cls:"bc-alert"},{test:t=>/\/\/\s*\?|#\s*\?/.test(t),cls:"bc-question"},{test:t=>/\/\/\s*\*[^/]|#\s*\*/.test(t),cls:"bc-highlight"},{test:t=>/\/\/\s*TODO|#\s*TODO/i.test(t),cls:"bc-todo"},{test:t=>/\/\/\s*FIXME|#\s*FIXME/i.test(t),cls:"bc-fixme"},{test:t=>/\/\/\s*NOTE|#\s*NOTE/i.test(t),cls:"bc-note"},{test:t=>/\/\/\s*\/\//.test(t),cls:"bc-strike"}];function g(){if(document.getElementById("bc-styles"))return;let t=document.createElement("style");t.id="bc-styles",t.textContent=`
    .cm-editor .cm-line.bc-alert,
    .cm-editor .cm-line.bc-alert *,
    .cm-editor .cm-line.bc-alert span,
    .cm-editor .cm-line.bc-alert .tok-comment,
    .cm-editor .cm-line.bc-alert .tok-lineComment { color: #FF3333 !important; font-weight: bold !important; }

    .cm-editor .cm-line.bc-question,
    .cm-editor .cm-line.bc-question *,
    .cm-editor .cm-line.bc-question span,
    .cm-editor .cm-line.bc-question .tok-comment,
    .cm-editor .cm-line.bc-question .tok-lineComment { color: #3399FF !important; }

    .cm-editor .cm-line.bc-highlight,
    .cm-editor .cm-line.bc-highlight *,
    .cm-editor .cm-line.bc-highlight span,
    .cm-editor .cm-line.bc-highlight .tok-comment,
    .cm-editor .cm-line.bc-highlight .tok-lineComment { color: #67D400 !important; font-weight: bold !important; }

    .cm-editor .cm-line.bc-todo,
    .cm-editor .cm-line.bc-todo *,
    .cm-editor .cm-line.bc-todo span,
    .cm-editor .cm-line.bc-todo .tok-comment,
    .cm-editor .cm-line.bc-todo .tok-lineComment { color: #FF8C00 !important; font-weight: bold !important; }

    .cm-editor .cm-line.bc-fixme,
    .cm-editor .cm-line.bc-fixme *,
    .cm-editor .cm-line.bc-fixme span,
    .cm-editor .cm-line.bc-fixme .tok-comment,
    .cm-editor .cm-line.bc-fixme .tok-lineComment { color: #FF4500 !important; font-weight: bold !important; }

    .cm-editor .cm-line.bc-note,
    .cm-editor .cm-line.bc-note *,
    .cm-editor .cm-line.bc-note span,
    .cm-editor .cm-line.bc-note .tok-comment,
    .cm-editor .cm-line.bc-note .tok-lineComment { color: #C679FF !important; }

    .cm-editor .cm-line.bc-strike,
    .cm-editor .cm-line.bc-strike *,
    .cm-editor .cm-line.bc-strike span,
    .cm-editor .cm-line.bc-strike .tok-comment,
    .cm-editor .cm-line.bc-strike .tok-lineComment {
      color: #555555 !important;
      text-decoration: line-through !important;
    }
  `,document.head.appendChild(t)}function d(){document.querySelectorAll(".cm-line").forEach(t=>{let e=t.textContent||"";for(let o of[...t.classList])o.startsWith("bc-")&&t.classList.remove(o);for(let o of u)if(o.test(e)){t.classList.add(o.cls);break}})}var m=null,l=null,r=null,s=null;function h(){l&&cancelAnimationFrame(l),l=requestAnimationFrame(()=>{l=null,d()}),r&&clearTimeout(r),r=setTimeout(()=>{r=null,d()},600)}function f(){d(),m=new MutationObserver(h),m.observe(document.body,{childList:!0,subtree:!0,characterData:!0})}function p(){m&&(m.disconnect(),m=null),l&&(cancelAnimationFrame(l),l=null),r&&(clearTimeout(r),r=null),document.querySelectorAll(".cm-line").forEach(t=>{for(let e of[...t.classList])e.startsWith("bc-")&&t.classList.remove(e)})}function x(t,e,o){t.settitle("Better Comments");let c=[{key:"showAlert",label:"! Alert",cls:"bc-alert",ex:"// ! will crash"},{key:"showQuestion",label:"? Question",cls:"bc-question",ex:"// ? is this right?"},{key:"showHighlight",label:"* Highlight",cls:"bc-highlight",ex:"// * important"},{key:"showTodo",label:"TODO",cls:"bc-todo",ex:"// TODO: fix this"},{key:"showFixme",label:"FIXME",cls:"bc-fixme",ex:"// FIXME: broken"},{key:"showNote",label:"NOTE",cls:"bc-note",ex:"// NOTE: see docs"},{key:"showStrike",label:"// Strikethrough",cls:"bc-strike",ex:"// // dead code"}];t.innerHTML=`
    <style>
      .bcs { padding:16px; font-family:monospace; color:var(--primary-text-color,#eee); }
      .bcs-head { font-size:11px; text-transform:uppercase; letter-spacing:1px;
        opacity:.4; margin-bottom:12px; }
      .bcs-row { display:flex; align-items:center; justify-content:space-between;
        padding:10px 0; border-bottom:1px solid rgba(255,255,255,.06); gap:8px; }
      .bcs-left { flex:1; }
      .bcs-label { font-size:13px; font-weight:bold; }
      .bcs-ex { font-size:11px; opacity:.4; margin-top:3px; }
      .tog { width:40px; height:22px; background:rgba(255,255,255,.12);
        border-radius:11px; position:relative; cursor:pointer;
        transition:background .2s; flex-shrink:0; }
      .tog.on { background:#67D400; }
      .tog::after { content:''; position:absolute; top:3px; left:3px;
        width:16px; height:16px; border-radius:50%; background:#fff;
        transition:transform .2s; }
      .tog.on::after { transform:translateX(18px); }
    </style>
    <div class="bcs">
      <div class="bcs-head">Tag Visibility</div>
      ${c.map(i=>`
        <div class="bcs-row">
          <div class="bcs-left">
            <div class="bcs-label ${i.cls}">${i.label}</div>
            <div class="bcs-ex">${i.ex}</div>
          </div>
          <div class="tog ${e[i.key]!==!1?"on":""}" data-key="${i.key}"></div>
        </div>
      `).join("")}
    </div>`,t.querySelectorAll(".tog").forEach(i=>{i.addEventListener("click",()=>{let n=i.dataset.key;e[n]=!e[n],i.classList.toggle("on",e[n]),o(e)})})}var b=class{constructor(){this.settings=this._load(),this.$page=null}async init(e,o,{firstInit:c}){this.$page=o,g(),this._applyVisibility(),f(),s=()=>h(),editorManager.on("file-content-changed",s),editorManager.on("switch-file",s),acode.require("commands").addCommand({name:"better-comments:settings",description:"Better Comments: Settings",exec:()=>{x(this.$page,this.settings,n=>{this.settings=n,this._save(),this._applyVisibility(),d()}),this.$page.show()}})}_applyVisibility(){let e={showAlert:"bc-alert",showQuestion:"bc-question",showHighlight:"bc-highlight",showTodo:"bc-todo",showFixme:"bc-fixme",showNote:"bc-note",showStrike:"bc-strike"},o="";for(let[i,n]of Object.entries(e))this.settings[i]===!1&&(o+=`.cm-editor .cm-line.${n},
                .cm-editor .cm-line.${n} * {
                  color: inherit !important;
                  font-weight: inherit !important;
                  text-decoration: none !important;
                }
`);let c=document.getElementById("bc-override");c||(c=document.createElement("style"),c.id="bc-override",document.head.appendChild(c)),c.textContent=o}_save(){try{localStorage.setItem(a+".s",JSON.stringify(this.settings))}catch{}}_load(){try{let e=localStorage.getItem(a+".s");if(e)return JSON.parse(e)}catch{}return{showAlert:!0,showQuestion:!0,showHighlight:!0,showTodo:!0,showFixme:!0,showNote:!0,showStrike:!0}}async destroy(){p(),s&&(editorManager.off("file-content-changed",s),editorManager.off("switch-file",s),s=null),document.getElementById("bc-styles")?.remove(),document.getElementById("bc-override")?.remove(),acode.require("commands").removeCommand("better-comments:settings")}};if(window.acode){let t=new b;acode.setPluginInit(a,(e,o,c)=>t.init(e,o,c)),acode.setPluginUnmount(a,()=>t.destroy())}})();
